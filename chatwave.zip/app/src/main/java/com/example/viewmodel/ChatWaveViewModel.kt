package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioHelper
import com.example.audio.RecordResult
import com.example.data.model.CallDirection
import com.example.data.model.CallRecord
import com.example.data.model.CallType
import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.data.model.MessageType
import com.example.data.model.StatusStory
import com.example.data.model.UserContact
import com.example.data.repository.ChatWaveRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab {
    CHATS,
    STATUS,
    CALLS
}

enum class ScreenState {
    AUTH,
    MAIN,
    CONVERSATION,
    CALL_SCREEN,
    STATUS_VIEW,
    STATUS_CREATE,
    ARCHIVED,
    STARRED,
    CONTACTS_PICKER,
    SETTINGS
}

data class ActiveCallState(
    val contactName: String = "",
    val contactAvatar: String = "",
    val callType: CallType = CallType.VOICE,
    val isIncoming: Boolean = false,
    val isConnected: Boolean = false,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false,
    val isVideoEnabled: Boolean = true,
    val isFrontCamera: Boolean = true
)

class ChatWaveViewModel(application: Application) : AndroidViewModel(application) {
    val repository = ChatWaveRepository(application)
    val audioHelper = AudioHelper(application)

    // User authentication state
    private val _isLoggedIn = MutableStateFlow(true)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _currentUserName = MutableStateFlow("Andi Wijaya")
    val currentUserName: StateFlow<String> = _currentUserName.asStateFlow()

    private val _currentUserEmail = MutableStateFlow("andi.wijaya@gmail.com")
    val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

    private val _currentUserPhone = MutableStateFlow("+62 812-9988-7766")
    val currentUserPhone: StateFlow<String> = _currentUserPhone.asStateFlow()

    private val _currentUserAbout = MutableStateFlow("Ada yang bisa dibantu? Gunakan ChatWave! 🚀")
    val currentUserAbout: StateFlow<String> = _currentUserAbout.asStateFlow()

    // Navigation and screen states
    private val _screenState = MutableStateFlow(ScreenState.MAIN)
    val screenState: StateFlow<ScreenState> = _screenState.asStateFlow()

    private val _currentTab = MutableStateFlow(AppTab.CHATS)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _selectedChatId = MutableStateFlow<String?>(null)
    val selectedChatId: StateFlow<String?> = _selectedChatId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    // Active conversation messages
    private val _activeChat = MutableStateFlow<ChatConversation?>(null)
    val activeChat: StateFlow<ChatConversation?> = _activeChat.asStateFlow()

    private val _activeMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val activeMessages: StateFlow<List<ChatMessage>> = _activeMessages.asStateFlow()

    // Message selection & action states
    private val _selectedMessageForAction = MutableStateFlow<ChatMessage?>(null)
    val selectedMessageForAction: StateFlow<ChatMessage?> = _selectedMessageForAction.asStateFlow()

    private val _replyingToMessage = MutableStateFlow<ChatMessage?>(null)
    val replyingToMessage: StateFlow<ChatMessage?> = _replyingToMessage.asStateFlow()

    private val _editingMessage = MutableStateFlow<ChatMessage?>(null)
    val editingMessage: StateFlow<ChatMessage?> = _editingMessage.asStateFlow()

    // Voice Note recording lock & preview
    private val _isRecordingLocked = MutableStateFlow(false)
    val isRecordingLocked: StateFlow<Boolean> = _isRecordingLocked.asStateFlow()

    private val _pendingRecordedResult = MutableStateFlow<RecordResult?>(null)
    val pendingRecordedResult: StateFlow<RecordResult?> = _pendingRecordedResult.asStateFlow()

    // Active call state
    private val _activeCall = MutableStateFlow<ActiveCallState?>(null)
    val activeCall: StateFlow<ActiveCallState?> = _activeCall.asStateFlow()

    private var callTimerJob: Job? = null

    // Status story viewing
    private val _activeViewingStatus = MutableStateFlow<StatusStory?>(null)
    val activeViewingStatus: StateFlow<StatusStory?> = _activeViewingStatus.asStateFlow()

    // Toast / snackbar alerts
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Repository flows
    val activeChats: StateFlow<List<ChatConversation>> = repository.activeChats
        .combine(_searchQuery) { chats, query ->
            if (query.isBlank()) chats
            else chats.filter { it.name.contains(query, ignoreCase = true) || it.lastMessageText.contains(query, ignoreCase = true) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedChats = repository.archivedChats.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val myStatuses = repository.myStatuses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentStatuses = repository.recentStatuses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allCalls = repository.allCalls.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allContacts = repository.allContacts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val starredMessages = repository.getStarredMessages().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleDarkTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun openChat(chatId: String) {
        _selectedChatId.value = chatId
        _screenState.value = ScreenState.CONVERSATION
        viewModelScope.launch {
            repository.getChatById(chatId).collect { chat ->
                _activeChat.value = chat
            }
        }
        viewModelScope.launch {
            repository.getMessagesForChat(chatId).collect { msgs ->
                _activeMessages.value = msgs
            }
        }
    }

    fun openChatWithContact(contact: UserContact) {
        val chatId = "chat_${contact.id}"
        viewModelScope.launch {
            val existing = repository.getChatById(chatId).stateIn(viewModelScope).value
            if (existing == null) {
                repository.sendMessage(
                    chatId = chatId,
                    text = "Hai ${contact.name}! Senang bisa terhubung di ChatWave.",
                    type = MessageType.TEXT
                )
            }
            openChat(chatId)
        }
    }

    fun backToMain() {
        _screenState.value = ScreenState.MAIN
        _selectedChatId.value = null
        _activeChat.value = null
        _selectedMessageForAction.value = null
        _replyingToMessage.value = null
        _editingMessage.value = null
        audioHelper.stopAudio()
    }

    fun navigateTo(screen: ScreenState) {
        _screenState.value = screen
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun selectMessage(msg: ChatMessage?) {
        _selectedMessageForAction.value = msg
    }

    fun setReplyingTo(msg: ChatMessage?) {
        _replyingToMessage.value = msg
        _selectedMessageForAction.value = null
    }

    fun setEditing(msg: ChatMessage?) {
        _editingMessage.value = msg
        _selectedMessageForAction.value = null
    }

    // Message Actions
    fun sendMessage(text: String) {
        val chatId = _selectedChatId.value ?: return
        val editing = _editingMessage.value

        viewModelScope.launch {
            if (editing != null) {
                repository.editMessage(editing.id, text)
                _editingMessage.value = null
                showToast("Pesan berhasil diedit")
            } else {
                repository.sendMessage(
                    chatId = chatId,
                    text = text,
                    type = MessageType.TEXT,
                    replyTo = _replyingToMessage.value
                )
                _replyingToMessage.value = null
            }
        }
    }

    fun sendVoiceNote(result: RecordResult) {
        val chatId = _selectedChatId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                text = "Pesan suara (${result.durationSeconds} detik)",
                type = MessageType.AUDIO,
                durationSeconds = result.durationSeconds,
                waveformPoints = result.waveformPoints,
                replyTo = _replyingToMessage.value
            )
            _replyingToMessage.value = null
            _pendingRecordedResult.value = null
            _isRecordingLocked.value = false
        }
    }

    fun sendPhoto(caption: String = "Foto") {
        val chatId = _selectedChatId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                text = caption,
                type = MessageType.IMAGE,
                mediaCaption = caption,
                replyTo = _replyingToMessage.value
            )
            _replyingToMessage.value = null
            showToast("Foto berhasil dikirim")
        }
    }

    fun sendDocument(fileName: String, sizeText: String) {
        val chatId = _selectedChatId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                text = fileName,
                type = MessageType.DOCUMENT,
                mediaName = fileName,
                mediaSizeText = sizeText,
                replyTo = _replyingToMessage.value
            )
            _replyingToMessage.value = null
            showToast("Dokumen berhasil dikirim")
        }
    }

    fun sendLocation(address: String, lat: Double, lng: Double) {
        val chatId = _selectedChatId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                text = address,
                type = MessageType.LOCATION,
                locationAddress = address,
                locationLat = lat,
                locationLng = lng,
                replyTo = _replyingToMessage.value
            )
            _replyingToMessage.value = null
            showToast("Lokasi berhasil dibagikan")
        }
    }

    fun sendContact(name: String, phone: String) {
        val chatId = _selectedChatId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                text = name,
                type = MessageType.CONTACT,
                contactName = name,
                contactPhone = phone,
                replyTo = _replyingToMessage.value
            )
            _replyingToMessage.value = null
            showToast("Kontak berhasil dibagikan")
        }
    }

    fun reactToMessage(messageId: String, emoji: String) {
        viewModelScope.launch {
            repository.reactToMessage(messageId, emoji)
            _selectedMessageForAction.value = null
        }
    }

    fun toggleStarSelectedMessage() {
        val msg = _selectedMessageForAction.value ?: return
        viewModelScope.launch {
            repository.toggleStar(msg.id)
            _selectedMessageForAction.value = null
            showToast(if (msg.isStarred) "Bintang dihapus" else "Pesan ditandai bintang ⭐")
        }
    }

    fun togglePinSelectedMessage() {
        val msg = _selectedMessageForAction.value ?: return
        viewModelScope.launch {
            repository.togglePin(msg.id)
            _selectedMessageForAction.value = null
            showToast(if (msg.isPinned) "Semat pesan dilepas" else "Pesan disematkan 📌")
        }
    }

    fun deleteSelectedMessage(forEveryone: Boolean) {
        val msg = _selectedMessageForAction.value ?: return
        viewModelScope.launch {
            if (forEveryone) {
                repository.deleteForEveryone(msg.id)
                showToast("Pesan dihapus untuk semua orang")
            } else {
                repository.deleteForMe(msg.id)
                showToast("Pesan dihapus untuk saya")
            }
            _selectedMessageForAction.value = null
        }
    }

    fun forwardSelectedMessage(targetChatId: String) {
        val msg = _selectedMessageForAction.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                chatId = targetChatId,
                text = msg.text,
                type = msg.type,
                mediaName = msg.mediaName,
                mediaCaption = msg.mediaCaption,
                durationSeconds = msg.durationSeconds,
                waveformPoints = msg.waveformPoints,
                locationAddress = msg.locationAddress,
                contactName = msg.contactName,
                contactPhone = msg.contactPhone
            )
            _selectedMessageForAction.value = null
            showToast("Pesan berhasil diteruskan")
        }
    }

    // Voice recording helpers
    fun startVoiceRecording() {
        audioHelper.startRecording()
    }

    fun lockVoiceRecording() {
        _isRecordingLocked.value = true
    }

    fun stopAndSendVoiceRecording() {
        val result = audioHelper.stopRecording()
        sendVoiceNote(result)
    }

    fun stopAndPreviewVoiceRecording() {
        val result = audioHelper.stopRecording()
        _pendingRecordedResult.value = result
    }

    fun cancelVoiceRecording() {
        audioHelper.cancelRecording()
        _isRecordingLocked.value = false
        _pendingRecordedResult.value = null
    }

    // Call functions
    fun startCall(contactName: String, contactAvatar: String, callType: CallType) {
        _activeCall.value = ActiveCallState(
            contactName = contactName,
            contactAvatar = contactAvatar,
            callType = callType,
            isIncoming = false,
            isConnected = false,
            durationSeconds = 0
        )
        _screenState.value = ScreenState.CALL_SCREEN

        // Simulate connecting after 2.5 seconds
        viewModelScope.launch {
            delay(2500)
            _activeCall.value = _activeCall.value?.copy(isConnected = true)
            startCallTimer()
        }
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _activeCall.value?.let { current ->
                    if (current.isConnected) {
                        _activeCall.value = current.copy(durationSeconds = current.durationSeconds + 1)
                    }
                }
            }
        }
    }

    fun toggleCallMute() {
        _activeCall.value = _activeCall.value?.copy(isMuted = !(_activeCall.value?.isMuted ?: false))
    }

    fun toggleCallSpeaker() {
        _activeCall.value = _activeCall.value?.copy(isSpeakerOn = !(_activeCall.value?.isSpeakerOn ?: false))
    }

    fun toggleCallVideo() {
        _activeCall.value = _activeCall.value?.copy(isVideoEnabled = !(_activeCall.value?.isVideoEnabled ?: true))
    }

    fun toggleCallCameraFlip() {
        _activeCall.value = _activeCall.value?.copy(isFrontCamera = !(_activeCall.value?.isFrontCamera ?: true))
    }

    fun endCall() {
        callTimerJob?.cancel()
        val current = _activeCall.value
        if (current != null) {
            viewModelScope.launch {
                repository.recordCall(
                    contactName = current.contactName,
                    callType = current.callType,
                    direction = if (current.isIncoming) CallDirection.INCOMING else CallDirection.OUTGOING,
                    durationSeconds = current.durationSeconds
                )
            }
        }
        _activeCall.value = null
        _screenState.value = if (_selectedChatId.value != null) ScreenState.CONVERSATION else ScreenState.MAIN
    }

    // Status / Stories
    fun viewStatus(status: StatusStory) {
        _activeViewingStatus.value = status
        _screenState.value = ScreenState.STATUS_VIEW
    }

    fun closeStatusView() {
        _activeViewingStatus.value = null
        _screenState.value = ScreenState.MAIN
    }

    fun createStatus(text: String, caption: String, bgHex: Long) {
        viewModelScope.launch {
            repository.addStatus(caption = caption, textStatus = text, bgHex = bgHex)
            _screenState.value = ScreenState.MAIN
            showToast("Status berhasil dibagikan (aktif 24 jam)")
        }
    }

    // User Profile & Settings
    fun updateProfile(name: String, about: String, phone: String) {
        _currentUserName.value = name
        _currentUserAbout.value = about
        _currentUserPhone.value = phone
        showToast("Profil berhasil diperbarui")
    }

    fun exportActiveChat(onExportDone: (String) -> Unit) {
        val chatId = _selectedChatId.value ?: return
        viewModelScope.launch {
            val content = repository.exportChat(chatId)
            onExportDone(content)
        }
    }
}
