package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "status_stories")
data class StatusStory(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String,
    val userAvatar: String = "",
    val isMyStatus: Boolean = false,
    val caption: String = "",
    val textStatus: String = "",
    val backgroundColorHex: Long = 0xFF128C7EL,
    val mediaUrl: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val viewsCount: Int = 0,
    val isViewed: Boolean = false
)
