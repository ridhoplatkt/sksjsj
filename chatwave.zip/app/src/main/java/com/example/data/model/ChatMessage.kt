package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MessageType {
    TEXT,
    IMAGE,
    VIDEO,
    AUDIO,       // Voice note (VN) or music
    DOCUMENT,
    LOCATION,
    CONTACT
}

enum class MessageStatus {
    SENDING,
    SENT,        // ✓
    DELIVERED,   // ✓✓ (abu-abu)
    READ         // ✓✓ (biru)
}

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey val id: String,
    val chatId: String,
    val senderId: String,
    val senderName: String,
    val isFromMe: Boolean,
    val text: String = "",
    val type: MessageType = MessageType.TEXT,
    val mediaUrl: String? = null,
    val mediaCaption: String? = null,
    val mediaSizeText: String? = null,
    val mediaName: String? = null,
    val durationSeconds: Int = 0,
    val waveformPoints: String = "", // Comma-separated integers e.g. "20,45,60,30,80..."
    val locationLatitude: Double = 0.0,
    val locationLongitude: Double = 0.0,
    val locationAddress: String = "",
    val contactName: String = "",
    val contactPhone: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.SENT,
    val replyToId: String? = null,
    val replyToSender: String? = null,
    val replyToText: String? = null,
    val reactions: String = "", // JSON or comma separated "❤️,👍"
    val isStarred: Boolean = false,
    val isPinned: Boolean = false,
    val isDeleted: Boolean = false,
    val isDeletedForEveryone: Boolean = false,
    val isEdited: Boolean = false,
    val editedAt: Long = 0L
)
