package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ChatConversation
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_conversations WHERE isArchived = 0 ORDER BY isPinned DESC, lastMessageTimestamp DESC")
    fun getActiveChats(): Flow<List<ChatConversation>>

    @Query("SELECT * FROM chat_conversations WHERE isArchived = 1 ORDER BY lastMessageTimestamp DESC")
    fun getArchivedChats(): Flow<List<ChatConversation>>

    @Query("SELECT * FROM chat_conversations WHERE id = :id LIMIT 1")
    fun getChatById(id: String): Flow<ChatConversation?>

    @Query("SELECT * FROM chat_conversations WHERE id = :id LIMIT 1")
    suspend fun getChatByIdDirect(id: String): ChatConversation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(chat: ChatConversation)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(chats: List<ChatConversation>)

    @Update
    suspend fun update(chat: ChatConversation)

    @Query("DELETE FROM chat_conversations WHERE id = :chatId")
    suspend fun deleteChat(chatId: String)

    @Query("UPDATE chat_conversations SET isPinned = NOT isPinned WHERE id = :chatId")
    suspend fun togglePin(chatId: String)

    @Query("UPDATE chat_conversations SET isMuted = NOT isMuted WHERE id = :chatId")
    suspend fun toggleMute(chatId: String)

    @Query("UPDATE chat_conversations SET isArchived = NOT isArchived WHERE id = :chatId")
    suspend fun toggleArchive(chatId: String)

    @Query("UPDATE chat_conversations SET typingText = :typing WHERE id = :chatId")
    suspend fun updateTypingStatus(chatId: String, typing: String?)

    @Query("UPDATE chat_conversations SET unreadCount = 0 WHERE id = :chatId")
    suspend fun clearUnread(chatId: String)
}
