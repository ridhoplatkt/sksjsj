package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.UserContact
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {
    @Query("SELECT * FROM user_contacts ORDER BY name ASC")
    fun getAllContacts(): Flow<List<UserContact>>

    @Query("SELECT * FROM user_contacts WHERE id = :id LIMIT 1")
    suspend fun getContactById(id: String): UserContact?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: UserContact)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(contacts: List<UserContact>)

    @Query("UPDATE user_contacts SET isBlocked = NOT isBlocked WHERE id = :id")
    suspend fun toggleBlockContact(id: String)
}
