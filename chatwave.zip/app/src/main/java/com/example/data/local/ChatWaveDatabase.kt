package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.CallRecord
import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.data.model.StatusStory
import com.example.data.model.UserContact

@Database(
    entities = [
        ChatConversation::class,
        ChatMessage::class,
        StatusStory::class,
        CallRecord::class,
        UserContact::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ChatWaveDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun messageDao(): MessageDao
    abstract fun statusDao(): StatusDao
    abstract fun callDao(): CallDao
    abstract fun contactDao(): ContactDao

    companion object {
        @Volatile
        private var INSTANCE: ChatWaveDatabase? = null

        fun getDatabase(context: Context): ChatWaveDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ChatWaveDatabase::class.java,
                    "chatwave_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
