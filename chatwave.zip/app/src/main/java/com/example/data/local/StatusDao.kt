package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.StatusStory
import kotlinx.coroutines.flow.Flow

@Dao
interface StatusDao {
    @Query("SELECT * FROM status_stories WHERE isMyStatus = 1 ORDER BY timestamp DESC")
    fun getMyStatuses(): Flow<List<StatusStory>>

    @Query("SELECT * FROM status_stories WHERE isMyStatus = 0 ORDER BY timestamp DESC")
    fun getRecentStatuses(): Flow<List<StatusStory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStatus(status: StatusStory)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(statuses: List<StatusStory>)

    @Query("UPDATE status_stories SET isViewed = 1 WHERE id = :statusId")
    suspend fun markAsViewed(statusId: String)

    @Query("DELETE FROM status_stories WHERE id = :statusId")
    suspend fun deleteStatus(statusId: String)
}
