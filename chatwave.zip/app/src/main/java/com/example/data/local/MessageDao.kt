package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ChatMessage
import com.example.data.model.MessageStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM chat_messages WHERE chatId = :chatId AND isDeleted = 0 ORDER BY timestamp ASC")
    fun getMessagesForChat(chatId: String): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages WHERE id = :id LIMIT 1")
    suspend fun getMessageById(id: String): ChatMessage?

    @Query("SELECT * FROM chat_messages WHERE chatId = :chatId AND isPinned = 1 AND isDeleted = 0 LIMIT 1")
    fun getPinnedMessage(chatId: String): Flow<ChatMessage?>

    @Query("SELECT * FROM chat_messages WHERE isStarred = 1 AND isDeleted = 0 ORDER BY timestamp DESC")
    fun getStarredMessages(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(messages: List<ChatMessage>)

    @Update
    suspend fun updateMessage(message: ChatMessage)

    @Query("UPDATE chat_messages SET status = :status WHERE chatId = :chatId AND isFromMe = 1")
    suspend fun updateStatusForChat(chatId: String, status: MessageStatus)

    @Query("UPDATE chat_messages SET reactions = :reactions WHERE id = :messageId")
    suspend fun updateReaction(messageId: String, reactions: String)

    @Query("UPDATE chat_messages SET isStarred = NOT isStarred WHERE id = :messageId")
    suspend fun toggleStar(messageId: String)

    @Query("UPDATE chat_messages SET isPinned = NOT isPinned WHERE id = :messageId")
    suspend fun togglePin(messageId: String)

    @Query("UPDATE chat_messages SET isDeleted = 1 WHERE id = :messageId")
    suspend fun deleteForMe(messageId: String)

    @Query("UPDATE chat_messages SET isDeletedForEveryone = 1, text = 'Pesan ini telah dihapus' WHERE id = :messageId")
    suspend fun deleteForEveryone(messageId: String)

    @Query("UPDATE chat_messages SET text = :newText, isEdited = 1, editedAt = :editedTime WHERE id = :messageId")
    suspend fun editMessage(messageId: String, newText: String, editedTime: Long)

    @Query("DELETE FROM chat_messages WHERE chatId = :chatId")
    suspend fun clearChatMessages(chatId: String)
}
