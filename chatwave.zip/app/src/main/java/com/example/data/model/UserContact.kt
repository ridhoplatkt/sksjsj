package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_contacts")
data class UserContact(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String,
    val email: String,
    val avatarUrl: String = "",
    val about: String = "Ada yang bisa dibantu? Gunakan ChatWave!",
    val isOnline: Boolean = true,
    val lastSeenText: String = "online",
    val isBlocked: Boolean = false
)
