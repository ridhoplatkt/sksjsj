package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CallType {
    VOICE,
    VIDEO
}

enum class CallDirection {
    INCOMING,
    OUTGOING,
    MISSED
}

@Entity(tableName = "call_records")
data class CallRecord(
    @PrimaryKey val id: String,
    val contactName: String,
    val contactAvatar: String = "",
    val callType: CallType = CallType.VOICE,
    val direction: CallDirection = CallDirection.INCOMING,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0
)
