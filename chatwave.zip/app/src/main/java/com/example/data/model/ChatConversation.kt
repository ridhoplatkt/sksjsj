package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_conversations")
data class ChatConversation(
    @PrimaryKey val id: String,
    val name: String,
    val phoneOrAbout: String,
    val avatarUrl: String = "",
    val isGroup: Boolean = false,
    val groupMembersCount: Int = 0,
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val isArchived: Boolean = false,
    val lastMessageText: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val lastMessageStatus: MessageStatus = MessageStatus.READ,
    val isOnline: Boolean = false,
    val lastSeenText: String = "online",
    val typingText: String? = null // e.g. "sedang mengetik..." or null
)
