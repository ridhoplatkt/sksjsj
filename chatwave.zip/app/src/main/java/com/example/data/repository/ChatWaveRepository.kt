package com.example.data.repository

import android.content.Context
import com.example.data.local.ChatWaveDatabase
import com.example.data.model.CallDirection
import com.example.data.model.CallRecord
import com.example.data.model.CallType
import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.data.model.MessageStatus
import com.example.data.model.MessageType
import com.example.data.model.StatusStory
import com.example.data.model.UserContact
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.UUID

class ChatWaveRepository(context: Context) {
    private val db = ChatWaveDatabase.getDatabase(context)
    private val chatDao = db.chatDao()
    private val messageDao = db.messageDao()
    private val statusDao = db.statusDao()
    private val callDao = db.callDao()
    private val contactDao = db.contactDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    init {
        scope.launch {
            checkAndSeedDatabase()
        }
    }

    val activeChats: Flow<List<ChatConversation>> = chatDao.getActiveChats()
    val archivedChats: Flow<List<ChatConversation>> = chatDao.getArchivedChats()
    val myStatuses: Flow<List<StatusStory>> = statusDao.getMyStatuses()
    val recentStatuses: Flow<List<StatusStory>> = statusDao.getRecentStatuses()
    val allCalls: Flow<List<CallRecord>> = callDao.getAllCalls()
    val allContacts: Flow<List<UserContact>> = contactDao.getAllContacts()

    fun getMessagesForChat(chatId: String): Flow<List<ChatMessage>> = messageDao.getMessagesForChat(chatId)
    fun getChatById(chatId: String): Flow<ChatConversation?> = chatDao.getChatById(chatId)
    fun getPinnedMessage(chatId: String): Flow<ChatMessage?> = messageDao.getPinnedMessage(chatId)
    fun getStarredMessages(): Flow<List<ChatMessage>> = messageDao.getStarredMessages()

    suspend fun sendMessage(
        chatId: String,
        text: String = "",
        type: MessageType = MessageType.TEXT,
        mediaUrl: String? = null,
        mediaCaption: String? = null,
        mediaName: String? = null,
        mediaSizeText: String? = null,
        durationSeconds: Int = 0,
        waveformPoints: String = "",
        locationLat: Double = 0.0,
        locationLng: Double = 0.0,
        locationAddress: String = "",
        contactName: String = "",
        contactPhone: String = "",
        replyTo: ChatMessage? = null
    ): ChatMessage {
        val msgId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()

        val newMsg = ChatMessage(
            id = msgId,
            chatId = chatId,
            senderId = "me",
            senderName = "Saya",
            isFromMe = true,
            text = text,
            type = type,
            mediaUrl = mediaUrl,
            mediaCaption = mediaCaption,
            mediaName = mediaName,
            mediaSizeText = mediaSizeText,
            durationSeconds = durationSeconds,
            waveformPoints = waveformPoints,
            locationLatitude = locationLat,
            locationLongitude = locationLng,
            locationAddress = locationAddress,
            contactName = contactName,
            contactPhone = contactPhone,
            timestamp = now,
            status = MessageStatus.SENT,
            replyToId = replyTo?.id,
            replyToSender = replyTo?.senderName,
            replyToText = replyTo?.text
        )

        messageDao.insertMessage(newMsg)

        // Update conversation summary
        val preview = when (type) {
            MessageType.TEXT -> text
            MessageType.AUDIO -> "🎤 Pesan Suara (${durationSeconds}s)"
            MessageType.IMAGE -> "📷 Foto"
            MessageType.VIDEO -> "🎥 Video"
            MessageType.DOCUMENT -> "📄 Dokumen: ${mediaName ?: "Berkas"}"
            MessageType.LOCATION -> "📍 Lokasi: $locationAddress"
            MessageType.CONTACT -> "👤 Kontak: $contactName"
        }

        val existingChat = chatDao.getChatByIdDirect(chatId)
        if (existingChat != null) {
            chatDao.update(
                existingChat.copy(
                    lastMessageText = preview,
                    lastMessageTimestamp = now,
                    lastMessageStatus = MessageStatus.SENT
                )
            )
        }

        // Simulate delivery and auto-reply from contact
        scope.launch {
            delay(1000)
            messageDao.updateMessage(newMsg.copy(status = MessageStatus.DELIVERED))

            delay(1200)
            messageDao.updateMessage(newMsg.copy(status = MessageStatus.READ))

            // Show typing indicator
            chatDao.updateTypingStatus(chatId, "sedang mengetik...")
            delay(2200)
            chatDao.updateTypingStatus(chatId, null)

            // Auto reply
            triggerAutoReply(chatId, type, text)
        }

        return newMsg
    }

    private suspend fun triggerAutoReply(chatId: String, userMsgType: MessageType, userText: String) {
        val chat = chatDao.getChatByIdDirect(chatId) ?: return
        val replies = when {
            userMsgType == MessageType.AUDIO -> listOf(
                "Voice note kamu sudah aku dengar, mantap dan jelas banget suaranya! 👍",
                "Oke siap, nanti kita sambung obrolan di telepon ya.",
                "Terima kasih VN-nya! Nanti aku kabarin lagi setelah meeting selesai."
            )
            userMsgType == MessageType.LOCATION -> listOf(
                "Lokasinya sudah kuterima! Aku meluncur ke sana sekarang.",
                "Oke, dekat kok dari sini. Tunggu sekitar 15 menit ya."
            )
            userMsgType == MessageType.DOCUMENT -> listOf(
                "Dokumen sudah berhasil diunduh dan dibuka. Terima kasih banyak!",
                "File sudah masuk. Akan segera saya review ya."
            )
            userMsgType == MessageType.IMAGE -> listOf(
                "Keren banget fotonya! Resolusinya jernih. ✨",
                "Wah bagus banget ini, makasih ya sudah dikirim!"
            )
            userText.contains("halo", ignoreCase = true) || userText.contains("hai", ignoreCase = true) -> listOf(
                "Halo juga! Ada kabar apa hari ini di ChatWave? 😊",
                "Hai! Senang banget dengar kabar dari kamu. Gimana harimu?"
            )
            userText.contains("meeting", ignoreCase = true) || userText.contains("proyek", ignoreCase = true) -> listOf(
                "Siap, progres proyek hari ini lancar. Semua tim sudah siap sprint.",
                "Noted! Nanti jam 2 siang kita bahas detailnya ya."
            )
            else -> listOf(
                "Baik, pesanmu sudah kuterima dengan baik. Ada yang mau ditambahkan lagi? 👍",
                "Oke siap! Semangat terus ya untuk hari ini! 🚀",
                "Terima kasih atas infonya. Nanti langsung aku follow up ya!"
            )
        }

        val replyText = replies.random()
        val replyId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()

        val replyMsg = ChatMessage(
            id = replyId,
            chatId = chatId,
            senderId = chat.id,
            senderName = chat.name,
            isFromMe = false,
            text = replyText,
            timestamp = now,
            status = MessageStatus.READ
        )

        messageDao.insertMessage(replyMsg)
        chatDao.update(
            chat.copy(
                lastMessageText = replyText,
                lastMessageTimestamp = now,
                lastMessageStatus = MessageStatus.READ,
                unreadCount = 0
            )
        )
    }

    suspend fun reactToMessage(messageId: String, emoji: String) {
        messageDao.updateReaction(messageId, emoji)
    }

    suspend fun toggleStar(messageId: String) {
        messageDao.toggleStar(messageId)
    }

    suspend fun togglePin(messageId: String) {
        messageDao.togglePin(messageId)
    }

    suspend fun deleteForMe(messageId: String) {
        messageDao.deleteForMe(messageId)
    }

    suspend fun deleteForEveryone(messageId: String) {
        messageDao.deleteForEveryone(messageId)
    }

    suspend fun editMessage(messageId: String, newText: String) {
        messageDao.editMessage(messageId, newText, System.currentTimeMillis())
    }

    suspend fun toggleChatPin(chatId: String) = chatDao.togglePin(chatId)
    suspend fun toggleChatMute(chatId: String) = chatDao.toggleMute(chatId)
    suspend fun toggleChatArchive(chatId: String) = chatDao.toggleArchive(chatId)
    suspend fun deleteChat(chatId: String) {
        chatDao.deleteChat(chatId)
        messageDao.clearChatMessages(chatId)
    }

    suspend fun addStatus(caption: String, textStatus: String, bgHex: Long) {
        val newStatus = StatusStory(
            id = UUID.randomUUID().toString(),
            userId = "me",
            userName = "Status Saya",
            isMyStatus = true,
            caption = caption,
            textStatus = textStatus,
            backgroundColorHex = bgHex,
            timestamp = System.currentTimeMillis(),
            viewsCount = 0,
            isViewed = false
        )
        statusDao.insertStatus(newStatus)
    }

    suspend fun recordCall(
        contactName: String,
        callType: CallType,
        direction: CallDirection,
        durationSeconds: Int
    ) {
        val record = CallRecord(
            id = UUID.randomUUID().toString(),
            contactName = contactName,
            callType = callType,
            direction = direction,
            timestamp = System.currentTimeMillis(),
            durationSeconds = durationSeconds
        )
        callDao.insertCall(record)
    }

    suspend fun exportChat(chatId: String): String {
        val messages = messageDao.getMessagesForChat(chatId).firstOrNull() ?: emptyList()
        val chat = chatDao.getChatByIdDirect(chatId)
        val sb = StringBuilder()
        sb.append("=== ChatWave Ekspor Obrolan: ${chat?.name ?: "Chat"} ===\n")
        sb.append("Tanggal Ekspor: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}\n\n")
        for (m in messages) {
            val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(m.timestamp))
            val sender = if (m.isFromMe) "Saya" else m.senderName
            val content = when (m.type) {
                MessageType.TEXT -> m.text
                MessageType.AUDIO -> "[Voice Note: ${m.durationSeconds} detik]"
                MessageType.IMAGE -> "[Foto: ${m.mediaCaption ?: ""}]"
                MessageType.VIDEO -> "[Video]"
                MessageType.DOCUMENT -> "[Dokumen: ${m.mediaName ?: "File"}]"
                MessageType.LOCATION -> "[Lokasi: ${m.locationAddress}]"
                MessageType.CONTACT -> "[Kontak: ${m.contactName} (${m.contactPhone})]"
            }
            sb.append("[$dateStr] $sender: $content\n")
        }
        return sb.toString()
    }

    private suspend fun checkAndSeedDatabase() {
        val currentChats = chatDao.getActiveChats().firstOrNull()
        if (!currentChats.isNullOrEmpty()) return

        // Seed realistic contacts
        val contacts = listOf(
            UserContact(
                id = "user_budi",
                name = "Budi Santoso",
                phone = "+62 812-3456-7890",
                email = "budi.santoso@example.com",
                about = "Sedang bekerja di kantor 💻",
                isOnline = true
            ),
            UserContact(
                id = "user_siti",
                name = "Siti Rahma",
                phone = "+62 813-9876-5432",
                email = "siti.rahma@example.com",
                about = "Hanya panggilan darurat 📞",
                isOnline = true
            ),
            UserContact(
                id = "user_andi",
                name = "Andi Pratama",
                phone = "+62 856-1122-3344",
                email = "andi.pratama@example.com",
                about = "Ada yang baru di ChatWave!",
                isOnline = false,
                lastSeenText = "hari ini pukul 12:45"
            ),
            UserContact(
                id = "user_dewi",
                name = "Dewi Lestari",
                phone = "+62 878-5566-7788",
                email = "dewi.lestari@example.com",
                about = "Available",
                isOnline = false,
                lastSeenText = "kemarin pukul 21:10"
            ),
            UserContact(
                id = "user_group_team",
                name = "Tim Kreatif & Dev",
                phone = "5 anggota",
                email = "team@chatwave.org",
                about = "Grup Diskusi Desain & Pengembangan",
                isOnline = true
            )
        )
        contactDao.insertAll(contacts)

        val now = System.currentTimeMillis()

        // Seed conversations
        val seedChats = listOf(
            ChatConversation(
                id = "chat_budi",
                name = "Budi Santoso",
                phoneOrAbout = "+62 812-3456-7890",
                isGroup = false,
                unreadCount = 2,
                isPinned = true,
                lastMessageText = "Halo, dokumen proposalnya sudah aku kirim ya.",
                lastMessageTimestamp = now - 1000 * 60 * 5,
                lastMessageStatus = MessageStatus.READ,
                isOnline = true,
                lastSeenText = "online"
            ),
            ChatConversation(
                id = "chat_siti",
                name = "Siti Rahma",
                phoneOrAbout = "+62 813-9876-5432",
                isGroup = false,
                unreadCount = 0,
                isPinned = false,
                lastMessageText = "🎤 Pesan Suara (12s)",
                lastMessageTimestamp = now - 1000 * 60 * 35,
                lastMessageStatus = MessageStatus.READ,
                isOnline = true,
                lastSeenText = "online"
            ),
            ChatConversation(
                id = "chat_team",
                name = "Tim Kreatif & Dev",
                phoneOrAbout = "5 anggota",
                isGroup = true,
                groupMembersCount = 5,
                unreadCount = 4,
                isPinned = true,
                lastMessageText = "Andi: Desain tampilan WhatsApp 100% sudah siap diuji!",
                lastMessageTimestamp = now - 1000 * 60 * 90,
                lastMessageStatus = MessageStatus.DELIVERED,
                isOnline = true,
                lastSeenText = "Budi, Siti, Andi, Dewi, Anda"
            ),
            ChatConversation(
                id = "chat_andi",
                name = "Andi Pratama",
                phoneOrAbout = "+62 856-1122-3344",
                isGroup = false,
                unreadCount = 0,
                isPinned = false,
                lastMessageText = "📍 Lokasi: Senayan Park, Jakarta Pusat",
                lastMessageTimestamp = now - 1000 * 60 * 60 * 3,
                lastMessageStatus = MessageStatus.READ,
                isOnline = false,
                lastSeenText = "hari ini pukul 12:45"
            ),
            ChatConversation(
                id = "chat_dewi",
                name = "Dewi Lestari",
                phoneOrAbout = "+62 878-5566-7788",
                isGroup = false,
                unreadCount = 0,
                isPinned = false,
                lastMessageText = "Sampai ketemu besok ya!",
                lastMessageTimestamp = now - 1000 * 60 * 60 * 24,
                lastMessageStatus = MessageStatus.READ,
                isOnline = false,
                lastSeenText = "kemarin pukul 21:10"
            )
        )
        chatDao.insertAll(seedChats)

        // Seed messages for chat_budi
        val budiMessages = listOf(
            ChatMessage(
                id = "msg_b1",
                chatId = "chat_budi",
                senderId = "user_budi",
                senderName = "Budi Santoso",
                isFromMe = false,
                text = "Hai! Gimana kabar progres aplikasi ChatWave?",
                timestamp = now - 1000 * 60 * 20,
                status = MessageStatus.READ
            ),
            ChatMessage(
                id = "msg_b2",
                chatId = "chat_budi",
                senderId = "me",
                senderName = "Saya",
                isFromMe = true,
                text = "Halo Budi! Sangat lancar, semua fitur mirip WhatsApp sudah terpasang rapi.",
                timestamp = now - 1000 * 60 * 18,
                status = MessageStatus.READ
            ),
            ChatMessage(
                id = "msg_b3",
                chatId = "chat_budi",
                senderId = "user_budi",
                senderName = "Budi Santoso",
                isFromMe = false,
                text = "Wah keren sekali! Bisa kirim dokumen dan voice note juga kan?",
                timestamp = now - 1000 * 60 * 10,
                status = MessageStatus.READ,
                reactions = "🔥"
            ),
            ChatMessage(
                id = "msg_b4",
                chatId = "chat_budi",
                senderId = "user_budi",
                senderName = "Budi Santoso",
                isFromMe = false,
                text = "Halo, dokumen proposalnya sudah aku kirim ya.",
                type = MessageType.DOCUMENT,
                mediaName = "Proposal_Pengembangan_ChatWave.pdf",
                mediaSizeText = "2.4 MB • PDF",
                timestamp = now - 1000 * 60 * 5,
                status = MessageStatus.READ
            )
        )
        messageDao.insertAll(budiMessages)

        // Seed messages for chat_siti (including authentic Voice Note!)
        val sitiMessages = listOf(
            ChatMessage(
                id = "msg_s1",
                chatId = "chat_siti",
                senderId = "me",
                senderName = "Saya",
                isFromMe = true,
                text = "Siti, nanti siang jadi panggilan video untuk sinkronisasi?",
                timestamp = now - 1000 * 60 * 45,
                status = MessageStatus.READ
            ),
            ChatMessage(
                id = "msg_s2",
                chatId = "chat_siti",
                senderId = "user_siti",
                senderName = "Siti Rahma",
                isFromMe = false,
                text = "Dengarkan pesan suara ini ya:",
                type = MessageType.AUDIO,
                durationSeconds = 12,
                waveformPoints = "25,40,70,85,60,95,45,30,80,65,90,50,35,75,40",
                timestamp = now - 1000 * 60 * 35,
                status = MessageStatus.READ,
                reactions = "❤️"
            )
        )
        messageDao.insertAll(sitiMessages)

        // Seed status stories
        val statuses = listOf(
            StatusStory(
                id = "status_siti",
                userId = "user_siti",
                userName = "Siti Rahma",
                caption = "Kopi sore sambil ngoding fitur realtime ☕",
                textStatus = "Enjoying the sunset and coding ChatWave 🌅",
                backgroundColorHex = 0xFF075E54L,
                timestamp = now - 1000 * 60 * 120,
                viewsCount = 14
            ),
            StatusStory(
                id = "status_budi",
                userId = "user_budi",
                userName = "Budi Santoso",
                caption = "Launching project baru minggu depan!",
                textStatus = "Ready for the big release! 🚀🎉",
                backgroundColorHex = 0xFF128C7EL,
                timestamp = now - 1000 * 60 * 240,
                viewsCount = 28
            )
        )
        statusDao.insertAll(statuses)

        // Seed call history
        val calls = listOf(
            CallRecord(
                id = "call_1",
                contactName = "Siti Rahma",
                callType = CallType.VIDEO,
                direction = CallDirection.INCOMING,
                timestamp = now - 1000 * 60 * 95,
                durationSeconds = 340
            ),
            CallRecord(
                id = "call_2",
                contactName = "Budi Santoso",
                callType = CallType.VOICE,
                direction = CallDirection.OUTGOING,
                timestamp = now - 1000 * 60 * 60 * 5,
                durationSeconds = 125
            ),
            CallRecord(
                id = "call_3",
                contactName = "Andi Pratama",
                callType = CallType.VOICE,
                direction = CallDirection.MISSED,
                timestamp = now - 1000 * 60 * 60 * 18,
                durationSeconds = 0
            )
        )
        callDao.insertAll(calls)
    }
}
