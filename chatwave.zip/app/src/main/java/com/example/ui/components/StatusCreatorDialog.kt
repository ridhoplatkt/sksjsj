package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.WaGreenAccent

@Composable
fun StatusCreatorDialog(
    onDismiss: () -> Unit,
    onPostStatus: (text: String, caption: String, bgHex: Long) -> Unit
) {
    val backgroundColors = listOf(
        0xFF075E54L, // WhatsApp Teal Dark
        0xFF128C7EL, // WhatsApp Teal Light
        0xFF5856D6L, // Purple
        0xFFFF2D55L, // Coral Red
        0xFFFF9500L, // Orange
        0xFF007AFFL, // Blue
        0xFF2C3E50L  // Slate Navy
    )

    var selectedColorIndex by remember { mutableIntStateOf(0) }
    var statusText by remember { mutableStateOf("") }

    val currentColorHex = backgroundColors[selectedColorIndex]

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(currentColorHex))
        ) {
            // Top Toolbar: Close & Color Swatch Cycler
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Batal",
                        tint = Color.White
                    )
                }

                IconButton(
                    onClick = {
                        selectedColorIndex = (selectedColorIndex + 1) % backgroundColors.size
                    },
                    modifier = Modifier.testTag("change_color_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ColorLens,
                        contentDescription = "Ganti Warna Latar",
                        tint = Color.White
                    )
                }
            }

            // Center: Status Text Input
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                BasicTextField(
                    value = statusText,
                    onValueChange = { statusText = it },
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("status_text_input"),
                    decorationBox = { innerTextField ->
                        if (statusText.isEmpty()) {
                            Text(
                                text = "Ketik status...",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 24.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        innerTextField()
                    }
                )
            }

            // Bottom Right: Send Floating Button
            if (statusText.isNotBlank()) {
                FloatingActionButton(
                    onClick = {
                        onPostStatus(statusText, statusText, currentColorHex)
                    },
                    containerColor = WaGreenAccent,
                    contentColor = Color.Black,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(24.dp)
                        .testTag("post_status_fab")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Kirim Status"
                    )
                }
            }
        }
    }
}
