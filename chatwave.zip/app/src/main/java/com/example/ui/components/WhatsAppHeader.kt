package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.WaTealGreen

@Composable
fun WhatsAppHeader(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenFirebaseInfo: () -> Unit,
    onOpenStarred: () -> Unit,
    onOpenArchived: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isSearchActive by remember { mutableStateOf(false) }
    var isMenuExpanded by remember { mutableStateOf(false) }

    val headerBg = if (isDarkTheme) MaterialTheme.colorScheme.surfaceVariant else WaTealGreen
    val headerTextColor = Color.White

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(headerBg)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        if (isSearchActive) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        isSearchActive = false
                        onSearchQueryChange("")
                    },
                    modifier = Modifier.testTag("close_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Tutup pencarian",
                        tint = headerTextColor
                    )
                }

                BasicTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    modifier = Modifier
                        .weight(1f)
                        .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("search_text_field"),
                    decorationBox = { innerTextField ->
                        if (searchQuery.isEmpty()) {
                            Text("Cari chat atau pesan...", color = Color.White.copy(alpha = 0.6f), fontSize = 15.sp)
                        }
                        innerTextField()
                    }
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ChatWave",
                    color = headerTextColor,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.testTag("app_title_text")
                )

                Spacer(modifier = Modifier.weight(1f))

                IconButton(
                    onClick = { /* Camera shortcut */ },
                    modifier = Modifier.testTag("camera_header_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = "Kamera",
                        tint = headerTextColor
                    )
                }

                IconButton(
                    onClick = { isSearchActive = true },
                    modifier = Modifier.testTag("search_header_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Cari",
                        tint = headerTextColor
                    )
                }

                Box {
                    IconButton(
                        onClick = { isMenuExpanded = true },
                        modifier = Modifier.testTag("menu_header_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Menu Opsi",
                            tint = headerTextColor
                        )
                    }

                    DropdownMenu(
                        expanded = isMenuExpanded,
                        onDismissRequest = { isMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Grup Baru") },
                            onClick = { isMenuExpanded = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Pesan Berbintang") },
                            onClick = {
                                isMenuExpanded = false
                                onOpenStarred()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Chat Diarsipkan") },
                            onClick = {
                                isMenuExpanded = false
                                onOpenArchived()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(if (isDarkTheme) "Mode Terang" else "Mode Gelap") },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = null
                                )
                            },
                            onClick = {
                                isMenuExpanded = false
                                onToggleDarkTheme()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Setup Firebase (Auth/Store/Rules)") },
                            onClick = {
                                isMenuExpanded = false
                                onOpenFirebaseInfo()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Setelan & Profil") },
                            onClick = {
                                isMenuExpanded = false
                                onOpenSettings()
                            }
                        )
                    }
                }
            }
        }
    }
}
