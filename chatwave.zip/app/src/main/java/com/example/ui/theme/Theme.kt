package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = WaGreenAccent,
    onPrimary = Color.Black,
    primaryContainer = WaDarkHeader,
    onPrimaryContainer = WaDarkTextPrimary,
    secondary = WaTealLight,
    onSecondary = Color.White,
    background = WaDarkBackground,
    onBackground = WaDarkTextPrimary,
    surface = WaDarkSurface,
    onSurface = WaDarkTextPrimary,
    surfaceVariant = WaDarkHeader,
    onSurfaceVariant = WaDarkTextSecondary,
    outline = WaDarkDivider
)

private val LightColorScheme = lightColorScheme(
    primary = WaTealGreen,
    onPrimary = Color.White,
    primaryContainer = WaTealLight,
    onPrimaryContainer = Color.White,
    secondary = WaGreenAccent,
    onSecondary = Color.White,
    background = WaBackgroundLight,
    onBackground = Color(0xFF111B21),
    surface = Color.White,
    onSurface = Color(0xFF111B21),
    surfaceVariant = Color(0xFFF0F2F5),
    onSurfaceVariant = WaSubtextLight,
    outline = WaDividerLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
