package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Forward
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.ChatMessage
import com.example.ui.theme.WaRed
import com.example.ui.theme.WaTealGreen

@Composable
fun MessageContextMenu(
    message: ChatMessage,
    onDismiss: () -> Unit,
    onSelectReaction: (String) -> Unit,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onForward: () -> Unit,
    onToggleStar: () -> Unit,
    onTogglePin: () -> Unit,
    onEdit: () -> Unit,
    onDeleteForMe: () -> Unit,
    onDeleteForEveryone: () -> Unit
) {
    val emojis = listOf("❤️", "👍", "😂", "😮", "😢", "🙏", "🔥")
    val canEdit = message.isFromMe && (System.currentTimeMillis() - message.timestamp < 15 * 60 * 1000)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Emoji Reaction Pill Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(24.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    emojis.forEach { emoji ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable { onSelectReaction(emoji) }
                                .testTag("react_$emoji"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emoji, fontSize = 20.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(8.dp))

                // Action Menu items
                ActionRow(
                    icon = Icons.AutoMirrored.Filled.Reply,
                    label = "Balas",
                    tag = "action_reply",
                    onClick = onReply
                )
                ActionRow(
                    icon = Icons.Default.ContentCopy,
                    label = "Salin Teks",
                    tag = "action_copy",
                    onClick = onCopy
                )
                ActionRow(
                    icon = Icons.Default.Forward,
                    label = "Teruskan",
                    tag = "action_forward",
                    onClick = onForward
                )
                ActionRow(
                    icon = Icons.Default.Star,
                    label = if (message.isStarred) "Hapus Bintang" else "Beri Bintang",
                    tag = "action_star",
                    onClick = onToggleStar
                )
                ActionRow(
                    icon = Icons.Default.PushPin,
                    label = if (message.isPinned) "Lepas Sematan" else "Sematkan Pesan",
                    tag = "action_pin",
                    onClick = onTogglePin
                )

                if (canEdit) {
                    ActionRow(
                        icon = Icons.Default.Edit,
                        label = "Edit Pesan (dalam 15 mnt)",
                        tag = "action_edit",
                        onClick = onEdit
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(8.dp))

                ActionRow(
                    icon = Icons.Default.Delete,
                    label = "Hapus untuk Saya",
                    tint = WaRed,
                    tag = "action_delete_me",
                    onClick = onDeleteForMe
                )

                if (message.isFromMe) {
                    ActionRow(
                        icon = Icons.Default.Delete,
                        label = "Hapus untuk Semua Orang",
                        tint = WaRed,
                        tag = "action_delete_all",
                        onClick = onDeleteForEveryone
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionRow(
    icon: ImageVector,
    label: String,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    tag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 8.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = label,
            fontSize = 15.sp,
            color = tint,
            fontWeight = FontWeight.Medium
        )
    }
}
