package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.WaGreenAccent
import com.example.ui.theme.WaTealGreen

@Composable
fun FirebaseInfoDialog(
    onDismiss: () -> Unit,
    onCopyRules: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Setup & Config", "Firestore Rules", "Storage Rules", "Skema Data")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(WaTealGreen)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Cloud,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.padding(4.dp))
                    Text(
                        text = "Panduan & Security Rules Firebase",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Tutup",
                            tint = Color.White
                        )
                    }
                }

                // Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = WaTealGreen
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(text = title, fontSize = 11.sp, maxLines = 1) }
                        )
                    }
                }

                // Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    when (selectedTab) {
                        0 -> SetupAndConfigView(onCopyRules)
                        1 -> FirestoreRulesView(onCopyRules)
                        2 -> StorageRulesView(onCopyRules)
                        3 -> DataSchemaView()
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupAndConfigView(onCopy: (String) -> Unit) {
    val configText = """
// 1. Buat project di https://console.firebase.google.com
// 2. Aktifkan Authentication (Email/Password)
// 3. Aktifkan Cloud Firestore Database
// 4. Aktifkan Firebase Storage
// 5. Salin config di bawah:
const firebaseConfig = {
  apiKey: "AIzaSyChatWaveSecureKey_Placeholder",
  authDomain: "chatwave-app.firebaseapp.com",
  projectId: "chatwave-app",
  storageBucket: "chatwave-app.appspot.com",
  messagingSenderId: "956817941879",
  appId: "1:956817941879:android:285b75ae"
};
""".trimIndent()

    Text("Langkah Integrasi Firebase", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(modifier = Modifier.height(6.dp))
    Text("Aplikasi ChatWave saat ini berjalan dengan local Room persistence + reactive auto-reply simulasi. Untuk menghubungkan ke akun Firebase live:", fontSize = 13.sp)

    Spacer(modifier = Modifier.height(10.dp))
    CodeBox(code = configText)

    Spacer(modifier = Modifier.height(12.dp))
    Button(
        onClick = { onCopy(configText) },
        colors = ButtonDefaults.buttonColors(containerColor = WaTealGreen),
        modifier = Modifier.fillMaxWidth().testTag("copy_config_btn")
    ) {
        Text("Salin Template Config Firebase")
    }
}

@Composable
private fun FirestoreRulesView(onCopy: (String) -> Unit) {
    val firestoreRules = """
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // User profile: hanya pemilik yang bisa update
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Chats: hanya anggota chat yang bisa baca & kirim
    match /chats/{chatId} {
      allow read, write: if request.auth != null && 
        (resource == null || request.auth.uid in resource.data.members);
        
      match /messages/{messageId} {
        allow read: if request.auth != null;
        allow create: if request.auth != null;
        allow update, delete: if request.auth != null && 
          request.auth.uid == resource.data.sender;
      }
    }

    // Status Stories (24 Jam)
    match /statuses/{statusId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null;
      allow delete: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    // WebRTC Signaling Calls
    match /calls/{callId} {
      allow read, write: if request.auth != null;
    }
  }
}
""".trimIndent()

    Text("Firestore Security Rules", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(modifier = Modifier.height(8.dp))
    CodeBox(code = firestoreRules)
    Spacer(modifier = Modifier.height(12.dp))
    Button(
        onClick = { onCopy(firestoreRules) },
        colors = ButtonDefaults.buttonColors(containerColor = WaTealGreen),
        modifier = Modifier.fillMaxWidth().testTag("copy_firestore_rules_btn")
    ) {
        Text("Salin Firestore Rules")
    }
}

@Composable
private fun StorageRulesView(onCopy: (String) -> Unit) {
    val storageRules = """
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Media Chat (Foto max 16MB, Video max 16MB, Dokumen max 100MB)
    match /chats/{chatId}/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.resource.size < 100 * 1024 * 1024;
    }
    
    // Voice Notes (Audio M4A / AAC)
    match /voicenotes/{userId}/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId && request.resource.size < 10 * 1024 * 1024;
    }
    
    // Foto Profil
    match /avatars/{userId}/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId && request.resource.size < 5 * 1024 * 1024;
    }
  }
}
""".trimIndent()

    Text("Firebase Storage Security Rules", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(modifier = Modifier.height(8.dp))
    CodeBox(code = storageRules)
    Spacer(modifier = Modifier.height(12.dp))
    Button(
        onClick = { onCopy(storageRules) },
        colors = ButtonDefaults.buttonColors(containerColor = WaTealGreen),
        modifier = Modifier.fillMaxWidth().testTag("copy_storage_rules_btn")
    ) {
        Text("Salin Storage Rules")
    }
}

@Composable
private fun DataSchemaView() {
    val schema = """
• users/{uid}
  - name: string
  - email: string
  - photoURL: string
  - status: "online" | "offline"
  - lastSeen: timestamp
  - about: string

• chats/{chatId}
  - members: [uid1, uid2]
  - lastMessage: string
  - updatedAt: timestamp
  - isGroup: boolean

• chats/{chatId}/messages/{msgId}
  - text: string
  - type: "TEXT" | "IMAGE" | "AUDIO" | "DOCUMENT" | "LOCATION" | "CONTACT"
  - mediaUrl: string
  - sender: uid
  - timestamp: timestamp
  - status: "SENT" | "DELIVERED" | "READ"
  - durationSeconds: number
  - reactions: string

• calls/{callId} (WebRTC Signaling)
  - caller: uid
  - receiver: uid
  - type: "VOICE" | "VIDEO"
  - offer: SDP offer
  - answer: SDP answer
  - iceCandidates: []

• statuses/{statusId}
  - userId: uid
  - caption: string
  - textStatus: string
  - bgHex: number
  - timestamp: timestamp
  - expiresAt: timestamp (+24h)
""".trimIndent()

    Text("Struktur & Skema Dokumen Firestore", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(modifier = Modifier.height(8.dp))
    CodeBox(code = schema)
}

@Composable
private fun CodeBox(code: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = code,
            color = Color(0xFF94A3B8),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            modifier = Modifier.padding(12.dp)
        )
    }
}
