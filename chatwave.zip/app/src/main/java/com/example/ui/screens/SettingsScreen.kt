package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.WaGreenAccent
import com.example.ui.theme.WaTealGreen

@Composable
fun SettingsScreen(
    userName: String,
    userAbout: String,
    userPhone: String,
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit,
    onEditProfile: () -> Unit,
    onOpenFirebaseInfo: () -> Unit,
    onOpenStarred: () -> Unit,
    onBackupData: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    val headerBg = if (isDarkTheme) MaterialTheme.colorScheme.surfaceVariant else WaTealGreen

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Top Bar
        Surface(
            color = headerBg,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_btn")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Kembali",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Setelan",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Profile Section Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onEditProfile() }
                .padding(16.dp)
                .testTag("profile_section_btn"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(WaTealGreen),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = userName,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = userAbout,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                Text(
                    text = userPhone,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        // Options List
        SettingsOptionRow(
            icon = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
            title = "Mode Gelap (Dark Mode)",
            subtitle = if (isDarkTheme) "Aktif" else "Nonaktif",
            tag = "toggle_dark_mode_row",
            trailing = {
                Switch(
                    checked = isDarkTheme,
                    onCheckedChange = { onToggleDarkTheme() },
                    colors = SwitchDefaults.colors(checkedThumbColor = WaGreenAccent, checkedTrackColor = WaTealGreen)
                )
            },
            onClick = onToggleDarkTheme
        )

        SettingsOptionRow(
            icon = Icons.Default.Cloud,
            title = "Panduan & Security Rules Firebase",
            subtitle = "Konfigurasi Auth, Firestore, Storage, dan Rules",
            tag = "open_firebase_row",
            onClick = onOpenFirebaseInfo
        )

        SettingsOptionRow(
            icon = Icons.Default.Star,
            title = "Pesan Berbintang",
            subtitle = "Lihat pesan yang Anda tandai dengan bintang",
            tag = "open_starred_row",
            onClick = onOpenStarred
        )

        SettingsOptionRow(
            icon = Icons.Default.Backup,
            title = "Cadangan Chat (Backup)",
            subtitle = "Cadangkan obrolan ke database lokal Room",
            tag = "backup_chat_row",
            onClick = onBackupData
        )

        SettingsOptionRow(
            icon = Icons.Default.Security,
            title = "Privasi & Keamanan",
            subtitle = "Enkripsi end-to-end simulasi, blokir kontak",
            tag = "privacy_row",
            onClick = { }
        )

        SettingsOptionRow(
            icon = Icons.Default.Notifications,
            title = "Notifikasi",
            subtitle = "Nada pesan, nada dering, getar",
            tag = "notifications_row",
            onClick = { }
        )

        SettingsOptionRow(
            icon = Icons.Default.Storage,
            title = "Penyimpanan dan Data",
            subtitle = "Unduh otomatis media, penggunaan jaringan",
            tag = "storage_row",
            onClick = { }
        )

        Spacer(modifier = Modifier.height(32.dp))
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "ChatWave v1.0.0", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = "Dibuat dengan Jetpack Compose & Material 3", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsOptionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tag: String,
    trailing: @Composable (() -> Unit)? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = WaTealGreen,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(20.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (trailing != null) {
            trailing()
        }
    }
}
