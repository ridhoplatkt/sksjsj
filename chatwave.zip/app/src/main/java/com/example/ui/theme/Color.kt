package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WhatsApp Signature Colors
val WaTealGreen = Color(0xFF075E54)
val WaTealLight = Color(0xFF128C7E)
val WaGreenAccent = Color(0xFF25D366)
val WaGreenLightBubble = Color(0xFFE7FFDB)
val WaWhite = Color(0xFFFFFFFF)
val WaCheckBlue = Color(0xFF34B7F1)
val WaCheckGray = Color(0xFF8696A0)
val WaSubtextLight = Color(0xFF667781)
val WaDividerLight = Color(0xFFE9EDEF)
val WaBackgroundLight = Color(0xFFEFEAE2)

// Dark Mode WhatsApp Colors
val WaDarkBackground = Color(0xFF0B141A)
val WaDarkSurface = Color(0xFF111B21)
val WaDarkHeader = Color(0xFF1F2C34)
val WaDarkBubbleSent = Color(0xFF005C4B)
val WaDarkBubbleReceived = Color(0xFF1F2C34)
val WaDarkTextPrimary = Color(0xFFE9EDEF)
val WaDarkTextSecondary = Color(0xFF8696A0)
val WaDarkDivider = Color(0xFF222D34)

// Danger & Accent
val WaRed = Color(0xFFEA0038)
val WaYellowStar = Color(0xFFFFB800)
