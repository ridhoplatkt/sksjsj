package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.CallType
import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.ui.components.AttachmentBottomSheet
import com.example.ui.components.MessageContextMenu
import com.example.ui.components.WhatsAppBubble
import com.example.ui.theme.WaGreenAccent
import com.example.ui.theme.WaRed
import com.example.ui.theme.WaTealGreen
import com.example.viewmodel.ChatWaveViewModel

import androidx.compose.material3.ExperimentalMaterial3Api

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatConversationScreen(
    viewModel: ChatWaveViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.backToMain()
    }

    val activeChat by viewModel.activeChat.collectAsState()
    val messages by viewModel.activeMessages.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val replyingTo by viewModel.replyingToMessage.collectAsState()
    val editingMsg by viewModel.editingMessage.collectAsState()
    val selectedMsgForAction by viewModel.selectedMessageForAction.collectAsState()

    val isRecording by viewModel.audioHelper.isRecording.collectAsState()
    val recordingDuration by viewModel.audioHelper.recordingDurationSeconds.collectAsState()
    val playingAudioId by viewModel.audioHelper.playingMessageId.collectAsState()
    val playbackProgress by viewModel.audioHelper.playbackProgress.collectAsState()
    val playbackSpeed by viewModel.audioHelper.playbackSpeed.collectAsState()
    val isRecordingLocked by viewModel.isRecordingLocked.collectAsState()

    var textInput by remember { mutableStateOf("") }
    var isMenuExpanded by remember { mutableStateOf(false) }
    var showAttachmentSheet by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    LaunchedEffect(editingMsg) {
        if (editingMsg != null) {
            textInput = editingMsg!!.text
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val headerBg = if (isDarkTheme) MaterialTheme.colorScheme.surfaceVariant else WaTealGreen

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
    ) {
        // WhatsApp Conversation Top App Bar
        Surface(
            color = headerBg,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.backToMain() },
                    modifier = Modifier.testTag("conversation_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Kembali",
                        tint = Color.White
                    )
                }

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = activeChat?.name ?: "Chat",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1
                    )
                    Text(
                        text = if (!activeChat?.typingText.isNullOrBlank()) activeChat!!.typingText!! else (activeChat?.lastSeenText ?: "online"),
                        color = if (!activeChat?.typingText.isNullOrBlank()) WaGreenAccent else Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }

                // Video Call Button
                IconButton(
                    onClick = {
                        activeChat?.let { chat ->
                            viewModel.startCall(chat.name, chat.avatarUrl, CallType.VIDEO)
                        }
                    },
                    modifier = Modifier.testTag("video_call_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Panggilan Video",
                        tint = Color.White
                    )
                }

                // Voice Call Button
                IconButton(
                    onClick = {
                        activeChat?.let { chat ->
                            viewModel.startCall(chat.name, chat.avatarUrl, CallType.VOICE)
                        }
                    },
                    modifier = Modifier.testTag("voice_call_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Panggilan Suara",
                        tint = Color.White
                    )
                }

                // 3 Dots Menu
                Box {
                    IconButton(onClick = { isMenuExpanded = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Menu Obrolan",
                            tint = Color.White
                        )
                    }

                    DropdownMenu(
                        expanded = isMenuExpanded,
                        onDismissRequest = { isMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Ekspor Chat (.txt)") },
                            onClick = {
                                isMenuExpanded = false
                                viewModel.exportActiveChat { exported ->
                                    viewModel.showToast("Obrolan berhasil diekspor (${exported.lines().size} baris)")
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Bisukan Notifikasi") },
                            onClick = {
                                isMenuExpanded = false
                                activeChat?.let { viewModel.repository }
                                viewModel.showToast("Notifikasi dibisukan")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Bersihkan Chat") },
                            onClick = {
                                isMenuExpanded = false
                                activeChat?.let { chat ->
                                    // Clear
                                }
                                viewModel.showToast("Pesan dibersihkan")
                            }
                        )
                    }
                }
            }
        }

        // WhatsApp Chat Wallpaper Background + Message List
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            // Doodle Wallpaper
            Image(
                painter = painterResource(id = R.drawable.img_chat_wallpaper),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = if (isDarkTheme) 0.08f else 0.18f
            )

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 8.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    WhatsAppBubble(
                        message = message,
                        isDarkTheme = isDarkTheme,
                        playingAudioId = playingAudioId,
                        playbackProgress = playbackProgress,
                        playbackSpeed = playbackSpeed,
                        onToggleAudioPlay = { id, dur ->
                            viewModel.audioHelper.playAudio(id, dur, playbackSpeed)
                        },
                        onCycleAudioSpeed = {
                            viewModel.audioHelper.cycleSpeed()
                        },
                        onLongPress = {
                            viewModel.selectMessage(message)
                        },
                        onClick = {
                            // If audio, toggle
                            if (message.type == com.example.data.model.MessageType.AUDIO) {
                                viewModel.audioHelper.playAudio(message.id, message.durationSeconds, playbackSpeed)
                            }
                        }
                    )
                }
            }
        }

        // Replying to message preview banner
        if (replyingTo != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Membalas ${replyingTo!!.senderName}:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = WaTealGreen
                    )
                    Text(
                        text = replyingTo!!.text,
                        fontSize = 12.sp,
                        maxLines = 1,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { viewModel.setReplyingTo(null) }) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Batal Balas")
                }
            }
        }

        // Editing message preview banner
        if (editingMsg != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Mengedit pesan:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = WaGreenAccent
                    )
                    Text(
                        text = editingMsg!!.text,
                        fontSize = 12.sp,
                        maxLines = 1,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = {
                    viewModel.setEditing(null)
                    textInput = ""
                }) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Batal Edit")
                }
            }
        }

        // Bottom WhatsApp Input Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isRecording) {
                // Voice Recording Live Bar
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(24.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Merekam",
                        tint = WaRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val recFormat = String.format("%02d:%02d", recordingDuration / 60, recordingDuration % 60)
                    Text(
                        text = recFormat,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = WaRed
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (isRecordingLocked) "Terkunci" else "Merekam VN...",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(
                        onClick = { viewModel.cancelVoiceRecording() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Batal",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (!isRecordingLocked) {
                        IconButton(
                            onClick = { viewModel.lockVoiceRecording() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Kunci Rekaman",
                                tint = WaTealGreen
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Send Recorded VN Button
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(WaGreenAccent)
                        .clickable { viewModel.stopAndSendVoiceRecording() }
                        .testTag("send_voice_note_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Kirim VN",
                        tint = Color.Black,
                        modifier = Modifier.size(22.dp)
                    )
                }
            } else {
                // Normal Text / Attachment Bar
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(24.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.showToast("Emoji picker siap digunakan") },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SentimentSatisfied,
                            contentDescription = "Emoji",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    BasicTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        textStyle = TextStyle(
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 16.sp
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp, vertical = 10.dp)
                            .testTag("chat_input_field"),
                        decorationBox = { innerTextField ->
                            if (textInput.isEmpty()) {
                                Text(
                                    text = "Ketik pesan...",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    fontSize = 15.sp
                                )
                            }
                            innerTextField()
                        }
                    )

                    IconButton(
                        onClick = { showAttachmentSheet = true },
                        modifier = Modifier.size(38.dp).testTag("attach_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = "Lampiran",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = { viewModel.sendPhoto("Foto dari Kamera 📸") },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Kamera Cepat",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Mic or Send Action Button
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(WaGreenAccent)
                        .clickable {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            } else {
                                // Start Voice Recording
                                viewModel.startVoiceRecording()
                            }
                        }
                        .testTag(if (textInput.isNotBlank()) "send_text_button" else "start_mic_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (textInput.isNotBlank()) Icons.AutoMirrored.Filled.Send else Icons.Default.Mic,
                        contentDescription = if (textInput.isNotBlank()) "Kirim" else "Rekam Suara",
                        tint = Color.Black,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }

    // Attachment Bottom Sheet
    if (showAttachmentSheet) {
        AttachmentBottomSheet(
            onDismiss = { showAttachmentSheet = false },
            onSelectDocument = {
                showAttachmentSheet = false
                viewModel.sendDocument("Laporan_Kinerja_ChatWave.pdf", "3.2 MB • PDF")
            },
            onSelectCamera = {
                showAttachmentSheet = false
                viewModel.sendPhoto("Foto Kamera Baru")
            },
            onSelectGallery = {
                showAttachmentSheet = false
                viewModel.sendPhoto("Galeri Gambar")
            },
            onSelectAudio = {
                showAttachmentSheet = false
                viewModel.sendVoiceNote(
                    com.example.audio.RecordResult(
                        filePath = "",
                        durationSeconds = 18,
                        waveformPoints = "30,50,75,90,65,40,85,60,70,95,50,45"
                    )
                )
            },
            onSelectLocation = {
                showAttachmentSheet = false
                viewModel.sendLocation("Senayan Park, Gelora, Jakarta Pusat", -6.2146, 106.8005)
            },
            onSelectContact = {
                showAttachmentSheet = false
                viewModel.sendContact("Budi Santoso", "+62 812-3456-7890")
            }
        )
    }

    // Message Context Menu (Long-press actions)
    if (selectedMsgForAction != null) {
        MessageContextMenu(
            message = selectedMsgForAction!!,
            onDismiss = { viewModel.selectMessage(null) },
            onSelectReaction = { emoji ->
                viewModel.reactToMessage(selectedMsgForAction!!.id, emoji)
            },
            onReply = {
                viewModel.setReplyingTo(selectedMsgForAction)
            },
            onCopy = {
                viewModel.selectMessage(null)
                viewModel.showToast("Teks pesan disalin ke clipboard")
            },
            onForward = {
                viewModel.selectMessage(null)
                viewModel.showToast("Pesan diteruskan")
            },
            onToggleStar = {
                viewModel.toggleStarSelectedMessage()
            },
            onTogglePin = {
                viewModel.togglePinSelectedMessage()
            },
            onEdit = {
                viewModel.setEditing(selectedMsgForAction)
            },
            onDeleteForMe = {
                viewModel.deleteSelectedMessage(forEveryone = false)
            },
            onDeleteForEveryone = {
                viewModel.deleteSelectedMessage(forEveryone = true)
            }
        )
    }
}
