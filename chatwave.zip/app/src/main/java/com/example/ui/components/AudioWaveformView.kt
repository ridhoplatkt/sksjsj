package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.WaCheckBlue
import com.example.ui.theme.WaCheckGray

@Composable
fun AudioWaveformView(
    messageId: String,
    durationSeconds: Int,
    waveformPoints: String,
    isPlaying: Boolean,
    playbackProgress: Float,
    playbackSpeed: Float,
    onTogglePlay: () -> Unit,
    onCycleSpeed: () -> Unit,
    isFromMe: Boolean,
    modifier: Modifier = Modifier
) {
    val points = waveformPoints.split(",").mapNotNull { it.trim().toIntOrNull() }.ifEmpty {
        listOf(20, 45, 60, 80, 50, 90, 70, 40, 65, 85, 30, 75, 55, 90, 40)
    }

    val activeColor = WaCheckBlue
    val inactiveColor = WaCheckGray

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Play / Pause Circle
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(activeColor.copy(alpha = 0.15f), CircleShape)
                .clickable { onTogglePlay() }
                .testTag("audio_play_button_$messageId"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Jeda Suara" else "Putar Suara",
                tint = activeColor,
                modifier = Modifier.size(26.dp)
            )
        }

        // Waveform Bars Canvas
        Box(
            modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxWidth().height(28.dp)) {
                val barWidth = 3.dp.toPx()
                val gap = 2.dp.toPx()
                val totalBars = points.size
                val currentPlayedIndex = (totalBars * playbackProgress).toInt()

                points.forEachIndexed { index, amp ->
                    val x = index * (barWidth + gap)
                    val normalizedAmp = (amp / 100f).coerceIn(0.2f, 1f)
                    val barHeight = size.height * normalizedAmp
                    val y = (size.height - barHeight) / 2

                    val barColor = if (index <= currentPlayedIndex && isPlaying) activeColor else inactiveColor

                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(x, y),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                }
            }
        }

        // Duration text
        val elapsed = if (isPlaying) (durationSeconds * playbackProgress).toInt() else durationSeconds
        val formattedTime = String.format("%02d:%02d", elapsed / 60, elapsed % 60)
        Text(
            text = formattedTime,
            fontSize = 11.sp,
            color = inactiveColor,
            modifier = Modifier.padding(end = 6.dp)
        )

        // Speed Chip (1x, 1.5x, 2x)
        Box(
            modifier = Modifier
                .background(Color.Black.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                .clickable { onCycleSpeed() }
                .padding(horizontal = 6.dp, vertical = 2.dp)
                .testTag("audio_speed_chip"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "${playbackSpeed}x",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = activeColor
            )
        }
    }
}
