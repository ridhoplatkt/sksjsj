package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.example.data.model.CallType
import com.example.ui.components.CallScreenView
import com.example.ui.components.ContactListSheet
import com.example.ui.components.FirebaseInfoDialog
import com.example.ui.components.ProfileEditDialog
import com.example.ui.components.StatusCreatorDialog
import com.example.ui.components.StatusViewerDialog
import com.example.ui.components.WhatsAppBottomNav
import com.example.ui.components.WhatsAppHeader
import com.example.ui.screens.ArchivedChatsScreen
import com.example.ui.screens.CallsListScreen
import com.example.ui.screens.ChatConversationScreen
import com.example.ui.screens.ChatListScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StarredMessagesScreen
import com.example.ui.screens.StatusListScreen
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import com.example.viewmodel.AppTab
import com.example.viewmodel.ChatWaveViewModel
import com.example.viewmodel.ScreenState

class MainActivity : ComponentActivity() {
    private val viewModel: ChatWaveViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            val screenState by viewModel.screenState.collectAsState()
            val currentTab by viewModel.currentTab.collectAsState()
            val toastMessage by viewModel.toastMessage.collectAsState()

            val activeChats by viewModel.activeChats.collectAsState()
            val archivedChats by viewModel.archivedChats.collectAsState()
            val myStatuses by viewModel.myStatuses.collectAsState()
            val recentStatuses by viewModel.recentStatuses.collectAsState()
            val allCalls by viewModel.allCalls.collectAsState()
            val allContacts by viewModel.allContacts.collectAsState()
            val starredMessages by viewModel.starredMessages.collectAsState()

            val activeCall by viewModel.activeCall.collectAsState()
            val activeStatus by viewModel.activeViewingStatus.collectAsState()
            val searchQuery by viewModel.searchQuery.collectAsState()

            val userName by viewModel.currentUserName.collectAsState()
            val userAbout by viewModel.currentUserAbout.collectAsState()
            val userPhone by viewModel.currentUserPhone.collectAsState()

            var showContactPicker by remember { mutableStateOf(false) }
            var showProfileEditor by remember { mutableStateOf(false) }
            var showFirebaseDialog by remember { mutableStateOf(false) }
            var showStatusCreator by remember { mutableStateOf(false) }

            val clipboardManager = LocalClipboardManager.current
            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(toastMessage) {
                toastMessage?.let {
                    Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show()
                    viewModel.clearToast()
                }
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (screenState) {
                            ScreenState.MAIN -> {
                                Column(modifier = Modifier.fillMaxSize()) {
                                    WhatsAppHeader(
                                        searchQuery = searchQuery,
                                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                                        isDarkTheme = isDarkTheme,
                                        onToggleDarkTheme = { viewModel.toggleDarkTheme() },
                                        onOpenSettings = { viewModel.navigateTo(ScreenState.SETTINGS) },
                                        onOpenFirebaseInfo = { showFirebaseDialog = true },
                                        onOpenStarred = { viewModel.navigateTo(ScreenState.STARRED) },
                                        onOpenArchived = { viewModel.navigateTo(ScreenState.ARCHIVED) }
                                    )

                                    Box(modifier = Modifier.weight(1f)) {
                                        when (currentTab) {
                                            AppTab.CHATS -> {
                                                ChatListScreen(
                                                    chats = activeChats,
                                                    archivedCount = archivedChats.size,
                                                    onChatClick = { chatId -> viewModel.openChat(chatId) },
                                                    onOpenArchived = { viewModel.navigateTo(ScreenState.ARCHIVED) },
                                                    onOpenContacts = { showContactPicker = true }
                                                )
                                            }

                                            AppTab.STATUS -> {
                                                StatusListScreen(
                                                    myStatuses = myStatuses,
                                                    recentStatuses = recentStatuses,
                                                    onViewStatus = { status -> viewModel.viewStatus(status) },
                                                    onCreateStatus = { showStatusCreator = true }
                                                )
                                            }

                                            AppTab.CALLS -> {
                                                CallsListScreen(
                                                    calls = allCalls,
                                                    onStartCall = { name, avatar, type ->
                                                        viewModel.startCall(name, avatar, type)
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    val unreadTotal = activeChats.sumOf { it.unreadCount }
                                    WhatsAppBottomNav(
                                        currentTab = currentTab,
                                        onTabSelected = { viewModel.setTab(it) },
                                        unreadChatsCount = unreadTotal,
                                        hasNewStatus = recentStatuses.any { !it.isViewed }
                                    )
                                }
                            }

                            ScreenState.CONVERSATION -> {
                                ChatConversationScreen(viewModel = viewModel)
                            }

                            ScreenState.CALL_SCREEN -> {
                                if (activeCall != null) {
                                    CallScreenView(
                                        callState = activeCall!!,
                                        onToggleMute = { viewModel.toggleCallMute() },
                                        onToggleSpeaker = { viewModel.toggleCallSpeaker() },
                                        onToggleVideo = { viewModel.toggleCallVideo() },
                                        onFlipCamera = { viewModel.toggleCallCameraFlip() },
                                        onEndCall = { viewModel.endCall() }
                                    )
                                }
                            }

                            ScreenState.SETTINGS -> {
                                SettingsScreen(
                                    userName = userName,
                                    userAbout = userAbout,
                                    userPhone = userPhone,
                                    isDarkTheme = isDarkTheme,
                                    onToggleDarkTheme = { viewModel.toggleDarkTheme() },
                                    onEditProfile = { showProfileEditor = true },
                                    onOpenFirebaseInfo = { showFirebaseDialog = true },
                                    onOpenStarred = { viewModel.navigateTo(ScreenState.STARRED) },
                                    onBackupData = {
                                        viewModel.showToast("Cadangan database lokal Room berhasil disimpan!")
                                    },
                                    onBack = { viewModel.backToMain() }
                                )
                            }

                            ScreenState.STARRED -> {
                                StarredMessagesScreen(
                                    messages = starredMessages,
                                    onBack = { viewModel.backToMain() }
                                )
                            }

                            ScreenState.ARCHIVED -> {
                                ArchivedChatsScreen(
                                    chats = archivedChats,
                                    onChatClick = { chatId -> viewModel.openChat(chatId) },
                                    onBack = { viewModel.backToMain() }
                                )
                            }

                            else -> {
                                viewModel.backToMain()
                            }
                        }

                        // Dialogs and Bottom Sheets
                        if (activeStatus != null) {
                            StatusViewerDialog(
                                status = activeStatus!!,
                                onClose = { viewModel.closeStatusView() },
                                onReply = { replyMsg ->
                                    viewModel.showToast("Balasan status terkirim: $replyMsg")
                                }
                            )
                        }

                        if (showStatusCreator) {
                            StatusCreatorDialog(
                                onDismiss = { showStatusCreator = false },
                                onPostStatus = { text, caption, bgHex ->
                                    viewModel.createStatus(text, caption, bgHex)
                                    showStatusCreator = false
                                }
                            )
                        }

                        if (showContactPicker) {
                            ContactListSheet(
                                contacts = allContacts,
                                onSelectContact = { contact ->
                                    viewModel.openChatWithContact(contact)
                                },
                                onDismiss = { showContactPicker = false }
                            )
                        }

                        if (showProfileEditor) {
                            ProfileEditDialog(
                                initialName = userName,
                                initialAbout = userAbout,
                                initialPhone = userPhone,
                                onDismiss = { showProfileEditor = false },
                                onSave = { newName, newAbout, newPhone ->
                                    viewModel.updateProfile(newName, newAbout, newPhone)
                                }
                            )
                        }

                        if (showFirebaseDialog) {
                            FirebaseInfoDialog(
                                onDismiss = { showFirebaseDialog = false },
                                onCopyRules = { codeToCopy ->
                                    clipboardManager.setText(AnnotatedString(codeToCopy))
                                    viewModel.showToast("Disalin ke Clipboard!")
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
